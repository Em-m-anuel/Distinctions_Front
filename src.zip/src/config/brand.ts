/* ------------------------------------------------------------------
   Ressources institutionnelles.

   Aucun fichier officiel de l'emblème de la République Gabonaise n'est
   présent dans le projet. Dès réception du fichier validé (SVG ou PNG
   transparent), le placer par exemple dans `src/assets/embleme-gabon.svg`
   puis renseigner ici :

     import emblem from "@/assets/embleme-gabon.svg";
     export const OFFICIAL_EMBLEM_SRC: string | null = emblem;

   Le composant <Emblem /> l'affichera automatiquement partout
   (en-tête, page de connexion, pied de page).
------------------------------------------------------------------ */

export const OFFICIAL_EMBLEM_SRC: string | null = null;

export const PORTAL_NAME = "Distinctions Nationales";
export const STATE_NAME = "République Gabonaise";
